package com.ativ.app.turma22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Turma22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
