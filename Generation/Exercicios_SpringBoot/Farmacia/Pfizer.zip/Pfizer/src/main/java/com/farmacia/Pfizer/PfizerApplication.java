package com.farmacia.Pfizer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PfizerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PfizerApplication.class, args);
	}

}
