package com.minhaLojaDeGames.Marvelous;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarvelousApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarvelousApplication.class, args);
	}

}
